import React, { Component } from 'react';
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'


import Tabs from '../common/tab/tabs.jsx'
import TabsHeader from '../common/tab/tabsHeader.jsx'
import TabsContent from '../common/tab/tabsContent.jsx'
import TabHeader from '../common/tab/tabHeader.jsx'
import TabContent from '../common/tab/tabContent.jsx'
import ContentHeader from '../common/template/content/contentHeader.jsx'
import Content from '../common/template/content/content.jsx'
import { init } from "./faturistaAction";
import Formulario from './form/formulario'


class Faturista extends Component {
    componentWillMount() {
        this.props.init()
    }
    
    render() {
        return (
            <div>
                <ContentHeader title='Cadastrar Faturista' small='Versão 1.0'/>
                <Content>
                    <Tabs>
                        <TabsHeader>
                            <TabHeader label='Listar' icon='bars' target='faturistaList' />
                            <TabHeader label='Incluir' icon='plus' target='faturistaCad' />
                        </TabsHeader>
                        <TabsContent>
                            <TabContent id='faturistaList'>
                                Listar
                            </TabContent>
                            <TabContent id='faturistaCad'>
                                <Formulario buttonName='Salvar'/>
                            </TabContent>
                        </TabsContent>
                    </Tabs>
                </Content>
            </div>
        )
    }
}


const mapDispatchToProps = dispatch => bindActionCreators({ init }, dispatch)
export default connect(null, mapDispatchToProps)(Faturista)