import React, { Component } from 'react'
import { connect } from 'react-redux'
import { reduxForm, Field } from 'redux-form'
import { bindActionCreators } from 'redux'

import labelAndInput from '../../common/form/labelAndInput.jsx'
import labelAndInputMask from '../../common/form/labelAndInputmask.jsx'
import { init } from '../faturistaAction'



class Formulario extends Component {

    render() {
        const { handleSubmit, submitting, readyOnly, buttonName } = this.props

        return(
                <div className='box box-primary'>
                    <form role='form' onSubmit={handleSubmit}>
                        <div className='box-body'>
                            <div className='box-body'>
                                <Field name='cpf' component={labelAndInputMask}
                                        label='Cpf'
                                        cols='12 4 '
                                        mask='111.111.111-11'
                                        readyOnly={readyOnly}

                                />
                                <Field name='nome' component={labelAndInput}
                                    label='Nome Completo' cols='12 4 '
                                    className='toUpper'
                                    readyOnly={readyOnly}

                                />
                                <Field name='data_nascimento' component={labelAndInput}
                                    label='Data nascimento'
                                    cols='12 4 '
                                    readyOnly={readyOnly}

                                />
                                <Field name='nome_mae' component={labelAndInput}
                                    label='Nome Da Mae' 
                                    cols='12 4 '
                                    readyOnly={readyOnly}
                                />
                                <Field name='plano_saude' component={labelAndInput}
                                    label='Plano de saude' 
                                    cols='12 4 '
                                    readyOnly={readyOnly}
                                />
                                <Field name='numero_plano' component={labelAndInput}
                                    label='Número da carteira do plano de saúde' 
                                    cols='12 4 '
                                    readyOnly={readyOnly}
                                />

                                <Field name='fixo' component={labelAndInput}
                                    label='Telefone fixo' 
                                    cols='12 4 '
                                    readyOnly={readyOnly}
                                />
                                <Field name='celular' component={labelAndInput}
                                    label='Celular' 
                                    cols='12 4 '
                                    readyOnly={readyOnly}
                                />
                                 <Field name='endereco' component={labelAndInput}
                                    label='Endereco' 
                                    cols='12 4 '
                                    readyOnly={readyOnly}
                                />
                                 <Field name='bairro' component={labelAndInput}
                                    label='Bairro' 
                                    cols='12 4 '
                                    readyOnly={readyOnly}
                                />
                                  <Field name='cep' component={labelAndInputMask}
                                    label='Cep' 
                                    cols='12 4 '
                                    mask='11111-111'
                                    readyOnly={readyOnly}
                                />
                                 <Field name='senha' component={labelAndInput}
                                    label='senha' 
                                    cols='12 2 '
                                    readyOnly={readyOnly}
                                />


                            </div>
                        </div>
                        <div className='box-footer'>
                            <button type='submit' className='btn btn-primary' disabled={submitting}>{buttonName}</button>
                            <button type='button' className='btn btn-default margin' onClick={() => this.props.init()}>Cancelar</button>
                        </div>
                    </form>
                </div>
        )
    }
}


Formulario = reduxForm({ form: 'faturista', destroyOnUnmount: false })(Formulario)
const mapDispatchToProps = dispatch => bindActionCreators({ init }, dispatch)
export default connect(null, mapDispatchToProps)(Formulario)