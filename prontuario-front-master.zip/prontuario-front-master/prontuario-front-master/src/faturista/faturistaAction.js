import { showTabs, selectTab } from '../common/tab/tabAction';

export function init() {
    
    return [
        showTabs('faturistaList', 'faturistaCad'),
        selectTab('faturistaList')
    ]
}