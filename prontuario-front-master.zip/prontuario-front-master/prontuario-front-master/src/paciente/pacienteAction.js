import { showTabs, selectTab } from '../common/tab/tabAction'
import { submit } from '../common/utils/utils'

const INITIAL_VALUES = {}

export function initPaciente(){
    return[
        showTabs('pacienteList', 'pacienteCad'),
        selectTab('pacienteList'),
    ]
}

export function criarPaciente(values) {
    return submit('post', 'paciente/criar', values, null, initPaciente)
}