import React, { Component } from 'react'
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'

import Tabs from '../common/tab/tabs.jsx'
import TabsHeader from '../common/tab/tabsHeader.jsx'
import TabsContent from '../common/tab/tabsContent.jsx'
import TabHeader from '../common/tab/tabHeader.jsx'
import TabContent from '../common/tab/tabContent.jsx'
import ContentHeader from '../common/template/content/contentHeader.jsx'
import Content from '../common/template/content/content.jsx'
import Formulario from './form/formulario'
import { initPaciente, criarPaciente } from './pacienteAction';

class Paciente extends Component {
    
    componentWillMount() {
        this.props.initPaciente()
    }

    render() {
        return (
            <div>
                <ContentHeader title='Cadastrar Paciente' small='Versão 1.0'/>
                <Content>
                    <Tabs>
                        <TabsHeader>
                            <TabHeader label='Listar' icon='bars' target='pacienteList' />
                            <TabHeader label='Incluir' icon='plus' target='pacienteCad' />
                        </TabsHeader>
                        <TabsContent>
                            <TabContent id='pacienteList'>
                                listar
                            </TabContent>
                            <TabContent id='pacienteCad'>
                                <Formulario buttonName='Criar' handleSubmit={this.props.criarPaciente} />
                            </TabContent>
                        </TabsContent>
                    </Tabs>
                </Content>
            </div>
        )
    }
}
const mapDispatchToProps = dispatch => bindActionCreators({ initPaciente, criarPaciente }, dispatch)

export default connect(null, mapDispatchToProps)(Paciente)