import React, { Component } from 'react'
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { ReactAgenda , ReactAgendaCtrl , guid ,  Modal } from 'react-agenda';

require('moment/locale/br.js');

var colors= {
    'color-1':"rgba(102, 195, 131 , 1)" ,
    "color-2":"rgba(242, 177, 52, 1)" ,
    "color-3":"rgba(235, 85, 59, 1)"
}
 
var now = new Date();

var items = [
{
    _id            :guid(),
    name          : 'Meeting , dev staff!',
    startDateTime : new Date(now.getFullYear(), now.getMonth(), now.getDate(), 10, 0),
    endDateTime   : new Date(now.getFullYear(), now.getMonth(), now.getDate(), 12, 0),
    classes       : 'color-1'
},
{
    _id            :guid(),
    name          : 'Working lunch , Holly',
    startDateTime : new Date(now.getFullYear(), now.getMonth(), now.getDate()+1, 11, 0),
    endDateTime   : new Date(now.getFullYear(), now.getMonth(), now.getDate()+1, 13, 0),
    classes       : 'color-2 color-3'
},

];

class Paciente extends Component {
    
    componentWillMount() {
    }

    render() {
        return (
            <div>
                <span>Agenda</span>
            </div>
        )
    }
}
const mapDispatchToProps = dispatch => bindActionCreators({}, dispatch)

export default connect(null, mapDispatchToProps)(Paciente)