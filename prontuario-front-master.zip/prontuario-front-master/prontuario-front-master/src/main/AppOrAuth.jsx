import '../common/template/dependencies.js'

import React, { Component } from 'react'
import axios from 'axios'
import { connect } from 'react-redux'

import App from './App.jsx'


class AuthOrApp extends Component {

    render() {
        if (true) {
            return <App>{this.props.children}</App>
        } 
    }
}


export default connect(null, null)(AuthOrApp)
