import React from 'react'
import { Route, Redirect, Switch } from 'react-router-dom'

import Paciente from '../paciente/paciente'
import Faturista from '../faturista/faturista'
import Medico from '../medico/medico'
import Agenda from '../agenda/agenda'


export default props => (
    <div className='content-wrapper'>
        <Switch> 
            <Route path="/paciente" component={Paciente} />
            <Route path="/faturista" component={Faturista} />
            <Route path="/medico" component={Medico} />
            <Route path="/agenda" component={Agenda} />
            <Redirect to='/' />
        </Switch>
    </div>

)