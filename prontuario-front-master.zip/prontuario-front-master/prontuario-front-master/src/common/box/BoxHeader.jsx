import React from 'react'

export default props => (
        <div className="box-header">
            {props.children}
        </div>
)