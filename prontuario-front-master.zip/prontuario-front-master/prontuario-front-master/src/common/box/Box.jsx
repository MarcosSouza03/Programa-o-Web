import React from 'react'
import IF from '../operator/if.jsx'

export default props => (
        <div className="box box-primary">
            {props.children}
        </div>
)