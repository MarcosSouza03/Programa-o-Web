import React from 'react'
import IF from '../operator/if.jsx'

export default props => (
        <div className="box-footer">
            {props.children}
        </div>
)