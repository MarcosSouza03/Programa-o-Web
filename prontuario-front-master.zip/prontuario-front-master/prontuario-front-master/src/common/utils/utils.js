import Axios from "axios"
import { toastr } from 'react-redux-toastr'
import consts from '../../consts'

export function submit(method, url, values, id, callBack) {
    return dispatch => {
        const ids = id ? id : ''
        Axios[method](`${consts.API_URL}/${url}/${ids}`, values)
            .then(resp => {
                toastr.toastr.success('Sucesso','Cadastro Realizado com sucesso');
                dispatch(callBack())
            })
            .catch(e => {
                e.response.data.Errors.forEach( error => toastr.error('Ops...',error))
            })
    }
}