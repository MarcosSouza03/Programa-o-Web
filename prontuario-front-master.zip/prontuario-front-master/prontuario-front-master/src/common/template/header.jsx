import React from 'react'
import Navbar from './navbar.jsx'
export default props =>(
    <header className='main-header'>
        <a href="/#/" className='logo'>
            <span className='logo-mini'><i class="fa fa-file-powerpoint-o" aria-hidden="true"></i></span>
            <span className='logo-lg'>
                 <i class="fa fa-file-powerpoint-o" aria-hidden="true"></i>
                 <b>Prontuario</b>
            </span>
        </a>
        <nav className='navbar navbar-static-top'>
            <a href='false' className='sidebar-toggle' data-toggle='offcanvas'></a>
            <Navbar />
        </nav>
    </header>
)