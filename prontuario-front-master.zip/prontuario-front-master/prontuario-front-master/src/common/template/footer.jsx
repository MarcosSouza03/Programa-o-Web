import React from 'react'

export default props => (
    <footer className='main-footer'>
        <strong>
            Aplicativo desenvolvido por marcos martins
            <a href="nada" target='_blank' className='margin'>MArcos</a>
        </strong>
    </footer>

)