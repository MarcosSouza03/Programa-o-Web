import React, { Component } from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'


class Navbar extends Component{
    constructor(props){
        super(props)
        this.state = { open: false }
    }
    changeOpen(){
        this.setState({open: !this.state.open })
    }
    render(){
        return(
            <div className="navbar-custom-menu">
                <ul className="nav navbar-nav">
                    <li onMouseLeave={() => this.changeOpen()} className={`dropdown user user-menu ${this.state.open ? 'open' : ''}`}>
                        <a href="javascript:;"
                            aria-expanded={this.state.open ? 'true' : 'false'}
                            className='dropdown-toggle'
                            data-toggle="dropdown">
                            <img src="http://lorempixel.com/160/160/abstract"  className="user-image" alt=""/>
                            <span className="hidden-xs">oi</span>
                        </a>
                        <ul className="dropdown-menu">
                            <li className="user-header">
                                <img src="http://lorempixel.com/160/160/abstract" className="img-circle" alt="" />
                            </li>
                            <li className="user-footer">
                                <div className="pull-right">
                                    <a href="#"  className="btn btn-default btn-flat"> Sair </a>
                                </div>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        )
    }
}

export default connect(null, null)(Navbar)