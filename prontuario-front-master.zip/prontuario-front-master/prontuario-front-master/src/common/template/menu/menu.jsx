import React, { Component } from 'react'
import { connect } from 'react-redux'

import MenuItem from './menuItem.jsx'
import MenuTree from './menuTree.jsx'

class Router extends Component{
    render(){
        return(
            <ul className='sidebar-menu'>
                <MenuItem label='Ínicio' icon='tachometer' path='/dashboard' />
                <MenuItem label='Prontuario' icon='fa fa-address-card-o' path='/prontuario'/>   
                <MenuItem label='Agenda' icon='fa fa-address-book' path='/agenda'/>    
                <MenuTree label='Cadastros' icon='cogs'>
                    <MenuItem label='Paciente' icon='child' path='/paciente'/>
                    <MenuItem label='Secretária(o)' icon='user-o' path='/secretario'/>
                    <MenuItem label='Faturista' icon='money' path='/faturista'/>
                    <MenuItem label='Médico(a)' icon='user-md' path='/medico'/>
                    <MenuItem label='Local Atendimento' icon='hospital-o' path='/atendimento'/>
                </MenuTree >
            </ul>

        )
    }
}

export default connect(null ,null)(Router)