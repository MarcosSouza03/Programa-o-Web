export default {
    API_URL: 'http://localhost:8091/api',
    OAPI_URL: 'http://localhost:8091/oapi',
    // API_URL: 'http://vps7545.publiccloud.com.br/api',
    // OAPI_URL: 'http://vps7545.publiccloud.com.br/oapi',
}

